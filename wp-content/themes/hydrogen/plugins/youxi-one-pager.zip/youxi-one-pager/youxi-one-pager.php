<?php
/*
Plugin Name: Youxi One Pager
Plugin URI: http://www.themeforest.net/user/nagaemas
Description: This plugin adds the ability to define a custom post type that can be used as content blocks with optional widget area. This is typically useful for one page themes that need to display content sequentially on a page as this plugin provides the functionality to attach the contents on a Wordpress native page. Besides the custom post type, this plugin also provides a basic nav walker class that can be used to create smart navigation menus that can detect where a block is located on one page themes.
Version: 1.2.1
Author: YouxiThemes
Author URI: http://www.themeforest.net/user/nagaemas
License: Envato Marketplace Licence
*/

/* Changelog:
1.2.1 - 12/08/2014
- Added 'youxi_one_pager_page_block_choices' filter for modifying available page blocks
- One pager post type is now excluded from search
- Adjusted nav walker to account for the current page

1.2 - 03/07/2014
- Fixed a bug that causes 'template_include' filter to always return the one pager template
- Support for Yoast SEO plugin by passing the modified page content to 'wpseo_pre_analysis_post_content'
- Code rewrite, update themes to ensure they keep working
- Page blocks are now cached by post id to reduce database queries in a single request
- Removed widget area functionality, it should be defined by themes instead

1.1 - 17/12/2013
- Removed manage page blocks page
- Page blocks management is now done on the edit post page
- Modified walker class to maintain compatibility with Youxi One Pager v1.0.x
- Added $post_id argument to 'leviate_one_pager_sidebar_args' filter hook

1.0.1 - 23/10/2013
- Changed the way the walker class is loaded

1.0
- Initial release
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Hi there!  I\'m just a plugin, not much I can do when called directly.' );
}

function youxi_one_pager_plugins_loaded() {

	if( ! defined( 'YOUXI_CORE_VERSION' ) ) {

		if( ! class_exists( 'Youxi_Admin_Notice' ) ) {
			require( plugin_dir_path( __FILE__ ) . 'class-admin-notice.php' );
		}
		Youxi_Admin_Notice::instance()->add_error( __FILE__, __( 'This plugin requires you to install and activate the Youxi Core plugin.', 'youxi' ) );

		return;
	}

	define( 'YOUXI_ONE_PAGER_VERSION', '1.2.1' );

	define( 'YOUXI_ONE_PAGER_DIR', plugin_dir_path( __FILE__ ) );

	define( 'YOUXI_ONE_PAGER_URL', plugin_dir_url( __FILE__ ) );

	define( 'YOUXI_ONE_PAGER_LANG_DIR', dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	/* Load Language File */
	load_plugin_textdomain( 'youxi', false, YOUXI_ONE_PAGER_LANG_DIR );

	/* Load the one pager class */
	if( ! class_exists( 'Youxi_One_Pager' ) ) {
		require( YOUXI_ONE_PAGER_DIR . 'classes/class-one-pager.php' );
	}

	/* Initialize */
	Youxi_One_Pager::instance();

	/* Load the walker class */
	if( ! is_admin() && ! class_exists( 'Youxi_One_Pager_Nav_Walker' ) ) {
		require( YOUXI_ONE_PAGER_DIR . 'classes/class-walker.php' );
	}
}
add_action( 'plugins_loaded', 'youxi_one_pager_plugins_loaded' );
