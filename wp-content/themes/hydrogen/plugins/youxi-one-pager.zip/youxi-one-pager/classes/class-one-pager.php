<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Hi there!  I\'m just a plugin, not much I can do when called directly.' );
}

if( ! class_exists( 'Youxi_One_Pager' ) ) {

	class Youxi_One_Pager {

		/**
		 * The Singleton instance
		 *
		 * @access private
		 * @var Youxi_One_Pager
		 */
		private static $instance;

		/**
		 * Public method to get the singleton instance
		 *
		 * @return Youxi_One_Pager
		 */
		public static function instance() {
			if( ! self::$instance ) {
				self::$instance = new Youxi_One_Pager();
			}

			return self::$instance;
		}

		private function __construct() {

			if( ! is_admin() ) {

				add_filter( 'wp_nav_menu_args', array( $this, 'wp_nav_menu_args' ) );
				add_filter( 'template_include', array( $this, 'template_include' ) );
			}

			add_action( 'init', array( $this, 'register_post_type' ) );
			add_action( 'admin_init', array( $this, 'attach_to_posts' ) );

			/* Filter for Yoast WP SEO */
			add_filter( 'wpseo_pre_analysis_post_content', array( $this, 'modify_post_content' ), 2, 2 );

			/* Filter for Youxi Shortcodes */
			add_filter( 'youxi_shortcode_pre_enqueue_post_content', array( $this, 'modify_post_content' ), 2, 2 );
		}

		/* Register one page post type */
		public function register_post_type() {

			/* Get the post type settings */
			$settings = wp_parse_args( self::post_type_args(), array(
				'args' => array(), 
				'labels' => array(), 
				'metaboxes' => array()
			));

			extract( $settings, EXTR_SKIP );

			/* Merge the labels into the args */
			$args = array_merge( $args, compact( 'labels' ) );

			/* Create the post type object */
			$post_type_object = Youxi_Post_Type::get( self::post_type_name(), $args );

			/* Add the metaboxes */
			foreach( $metaboxes as $metabox_id => $metabox ) {
				$post_type_object->add_meta_box( new Youxi_Metabox( $metabox_id, $metabox ) );
			}

			/* Register the post type */
			$post_type_object->register();
		}

		/* Attach page block to posts */
		public function attach_to_posts() {

			/* Fetch all page blocks */
			$args = array(
				'post_type' => self::post_type_name(), 
				'numberposts' => -1, 
				'cache_results' => false
			);
			
			$page_block_choices = array();
			if( $page_blocks = get_posts( $args ) ) {
				foreach( $page_blocks as $page_block ) {
					$page_block_choices[ $page_block->ID ] = $page_block->post_title;
				}
			}

			/* Provide a filter to account for other plugins */
			$page_block_choices = apply_filters( 'youxi_one_pager_block_choices', $page_block_choices );

			/* Get the 'metabox' settings */
			$mb_fields = array();
			$mb_fields[ self::meta_key() ] = array(
				'type' => 'multiselect', 
				'label' => __( 'Page Blocks', 'youxi' ), 
				'description' => __( 'Attach page blocks on this post. The post content will be overriden when there is one or more page block attached.', 'youxi' ), 
				'choices' => $page_block_choices
			);

			$metaboxes = array();
			$metaboxes[ self::post_type_name() ] = array(
				'title' => __( 'Page Blocks', 'youxi' ), 
				'as_array' => false, 
				'fields' => $mb_fields
			);

			/* Create the attached post type object */
			foreach( self::attached_post_types() as $post_type ) {

				/* Make sure it's an existing post type */
				if( ! post_type_exists( $post_type ) ) {
					continue;
				}

				/* Get the post type wrapper object */
				$post_type_object = Youxi_Post_Type::get( $post_type );

				/* Add the metaboxes */
				foreach( $metaboxes as $metabox_id => $metabox ) {
					$post_type_object->add_meta_box( new Youxi_Metabox( $metabox_id, $metabox ) );
				}
			}
		}

		/* Filter wp_nav_menu arguments so we can hook the nav walker appropriately */
		public function wp_nav_menu_args( $args ) {
			/* Bail if wp_nav_menu args does not contain theme_location or a custom walker is defined */
			if( ! isset( $args['theme_location'] ) || ( isset( $args['walker'] ) && '' !== $args['walker'] ) ) {
				return $args;
			}

			/* Also bail if the nav menu theme_location is not in the allowed list */
			$allowed_theme_locations = apply_filters( 'youxi_one_pager_override_nav_walker', array() );
			if( ! in_array( $args['theme_location'], $allowed_theme_locations ) ) {
				return $args;
			}

			$args['walker'] = new Youxi_One_Pager_Nav_Walker();

			return $args;
		}

		/* Filter template_include for posts containing one page blocks */
		public function template_include( $template ) {

			global $post;
			$blocks = self::get_blocks( $post );
			if( is_array( $blocks ) && ! empty( $blocks ) && get_queried_object_id() == $post->ID ) {

				$templates = array(
					"one-pager-{$post->post_name}.php", 
					"one-pager-{$post->ID}.php", 
					'one-pager.php'
				);

				$located = locate_template( $templates );

				if( '' !== $located ) {
					$template = $located;
				}
			}

			return $template;
		}

		/* Filter post content, attaching one page blocks to the current content */
		public static function modify_post_content( $post_content, $post ) {

			if( $posts = self::get_blocks( $post, true ) ) {
				$post_content .= implode( '', wp_list_pluck( $posts, 'post_content' ) );
			}

			return $post_content;
		}

		/* The one page blocks attached to a page, if any */
		public static function get_blocks( $post, $fetch_blocks = false ) {

			$post = get_post( $post );
			
			/* If the queried object is one of the post types to attach and not the blog index page */
			if( is_a( $post, 'WP_Post' ) && in_array( $post->post_type, self::attached_post_types() ) && 
				get_option( 'page_for_posts' ) != $post->ID ) {

				$page_blocks = $post->{self::meta_key()};

				if( $fetch_blocks && ! empty( $page_blocks ) ) {

					/* We're here if we want to get the actual block post objects instead of only their IDs */
					return get_posts(array(
						'post_type' => self::post_type_name(), 
						'posts_per_page' => -1, 
						'post__in' => $page_blocks, 
						'orderby' => 'post__in', 
						'suppress_filters' => false
					));
				}

				return $page_blocks;
			}
		}

		/* The post meta name where one page blocks are saved */
		public static function meta_key() {
			return apply_filters( 'youxi_one_pager_meta_key', 'youxi_one_pager_blocks' );
		}

		/* The post type name for the one page blocks */
		public static function post_type_name() {
			return apply_filters( 'youxi_one_pager_post_type_name', 'page-block' );
		}

		/* The post type(s) that allows attaching one page blocks */
		public static function attached_post_types() {
			return (array) apply_filters( 'youxi_one_pager_attached_post_type', 'page' );
		}

		/* The one page post type arguments */
		public static function post_type_args() {
			/* Return the settings for the page block cpt */
			return array(
				'args' => apply_filters( 'youxi_one_pager_cpt_args', array(
					'description' => __( 'This post type is used to display the page blocks', 'youxi' ), 
					'capability_type' => 'page', 
					'public' => true, 
					'has_archive' => false, 
					'exclude_from_search' => true, 
					'supports' => array( 'title', 'editor', 'revisions' )
				) ), 

				'labels' => apply_filters( 'youxi_one_pager_cpt_labels', array(
					'name'              =>__( 'Page Blocks', 'youxi' ), 
					'singular_name'     =>__( 'Page Block', 'youxi' ), 
					'add_new'           =>__( 'Add New Page Block', 'youxi' ),
					'add_new_item'      =>__( 'Add New Page Block', 'youxi' ),
					'edit_item'         =>__( 'Edit Page Block', 'youxi' ),
					'view_item'         =>__( 'View Page Block', 'youxi' ),
					'search_items'      =>__( 'Search Page Blocks', 'youxi' ),
					'not_found'         =>__( 'Page block not found', 'youxi' ),
					'not_found_in_trash' => __( 'Page block not found in trash', 'youxi' ),
					'parent_item_colon' =>__( 'Page Block: ', 'youxi' )
				) ), 

				'metaboxes' => apply_filters( 'youxi_one_pager_cpt_metaboxes', array() )
			);
		}
	}
}