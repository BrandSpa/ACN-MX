<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Hi there!  I\'m just a plugin, not much I can do when called directly.' );
}

if( ! class_exists( 'Youxi_One_Pager_Nav_Walker' ) ) {

	class Youxi_One_Pager_Nav_Walker extends Walker_Nav_Menu {

		private $current_blocks = array();

		private $other_posts = array();

		function __construct() {

			/* Fetch page blocks from the currently queried object */
			$blocks = Youxi_One_Pager::get_blocks( get_queried_object_id() );
			$this->current_blocks = is_array( $blocks ) ? $blocks : array();

			/* Get the other posts */
			$other_posts = get_posts(array(
				'post_type' => Youxi_One_Pager::attached_post_types(), 
				'posts_per_page' => -1, 
				'suppress_filters' => false, 
				'exclude' => get_queried_object_id()
			));

			/* Loop through the other posts, and check for blocks */
			foreach( $other_posts as $post ) {

				if( get_option( 'page_for_posts', '' ) == $post->ID )
					continue;

				$blocks = Youxi_One_Pager::get_blocks( $post );

				if( $blocks ) {
					$this->other_posts[ $post->ID ] = $blocks;
				}
			}
		}

		function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

			/* If the current item is not a taxonomy object */
			if( 'post_type' == $item->type ) {

				/* If the current menu item points to a block post type */
				if( Youxi_One_Pager::post_type_name() == $item->object ) {

					/* If the page block is attached on the current post */
					if( in_array( $item->object_id, $this->current_blocks ) ) {

						$url_prefix = '';

					} else {

						/* Find the page block on other posts  */
						foreach( $this->other_posts as $post_id => $blocks ) {

							if( is_array( $blocks ) && in_array( $item->object_id, $blocks ) ) {
								// Page block found, get permalink to the containing post
								$url_prefix = get_permalink( $post_id );
								break;
							}
						}
					}

					$post = get_post( $item->object_id );

					/* We're here if the block is found either on this post or an another post */
					if( isset( $url_prefix ) && is_a( $post, 'WP_Post' ) ) {
						$item->url = $url_prefix . '#' . $post->post_name;
					}
				}

				/*
					If the current queried object has blocks.
					Having blocks inside means that the queried object is:
					- One of the post types to attach page blocks
					- Not the blog index page
				*/
				elseif( ! empty( $this->current_blocks ) ) {

					/* If the current menu item points to the queried object */
					if( get_queried_object_id() == $item->object_id && is_singular() ) {
						if( ( $key = array_search( 'current-menu-item', $item->classes ) ) !== false ) {
							$item->url = '#';
							unset( $item->classes[ $key ] );
						}
					}
				}
			}

			parent::start_el( $output, $item, $depth, $args, $id );
		}
	}
}